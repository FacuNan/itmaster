
"""
y = f(x)
resultado = cuadrado(2)
"""
import random 

PI = 3.14

def cuadrado(x):  
    return x*x

# PROGRAMA PRINCIPAL
def main():
    resultado = cuadrado(2)
    resultado = cuadrado(3)
    resultado = cuadrado(4)
    pepe = 25
    resultado = cuadrado(pepe)
    


main() # <== PUNTO DE ENTRADA







