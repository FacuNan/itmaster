
"""
Dado un numero entre 1 y 12. Indicar el nombre del mes.
"""


mes = 1

nombre = ""
if mes == 1:
    nombre = "Enero"
elif mes == 2:
    pass
elif mes == 3:
    pass
elif mes == 4:
    pass
elif mes == 5:
    pass
elif mes == 6:
    pass
elif mes == 7:
    pass
elif mes == 8:
    pass
elif mes == 9:
    pass
elif mes == 10:
    pass
elif mes == 11:
    pass
else:
    pass

print(nombre)
