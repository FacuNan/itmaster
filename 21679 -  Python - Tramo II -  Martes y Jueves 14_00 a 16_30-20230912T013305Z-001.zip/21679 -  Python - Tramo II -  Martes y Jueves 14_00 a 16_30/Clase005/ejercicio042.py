"""
Ejercicio 042

Escribir un programa que lea números enteros hasta que se 
ingrese un 0, y muestre el promedio de los números ingresados.
"""