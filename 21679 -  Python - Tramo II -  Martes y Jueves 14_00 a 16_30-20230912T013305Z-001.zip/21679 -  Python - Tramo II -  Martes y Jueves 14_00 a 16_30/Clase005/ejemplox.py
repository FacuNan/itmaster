
r = range(1,11,2)
print(r)
print(list(r))

