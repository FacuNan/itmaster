a = int(input("Ingrese un valor: "))
if not a:
    print("No es definida a")