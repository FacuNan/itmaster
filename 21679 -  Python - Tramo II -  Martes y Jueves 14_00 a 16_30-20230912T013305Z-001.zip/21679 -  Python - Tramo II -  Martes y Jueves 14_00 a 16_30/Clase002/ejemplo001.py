enunciado= """
Leer dos numeros luego mostrar la suma.

leer dos numeros
    leer un numero
    leer un numero    

hacer la suma

mostrar el resultado
"""


print(enunciado)
numero_uno = input("Ingrese un numero: ")
numero_uno = int(numero_uno)

numero_dos = int(     input("Ingrese un numero: ")    )


suma = numero_uno + numero_dos

print(suma)



























