lista = []
print(lista)
lista = list()
print(lista)
lista = list( (2,)   ) 
print(lista)
x = 2,
print(x)