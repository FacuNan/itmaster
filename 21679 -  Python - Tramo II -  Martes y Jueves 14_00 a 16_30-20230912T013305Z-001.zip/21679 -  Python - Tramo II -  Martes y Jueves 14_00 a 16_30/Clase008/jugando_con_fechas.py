import sys
sys.path.append('recursos/')


import fechas_int as fech

def main():
    print(fech.str_fecha(20211221))
    


main()




