




a = 2





a = int(0)
b = "pepe"
c = 3.0
d = a
a = 'kjWEDGDHF"U"!IJKEGD'
s = 3+3








